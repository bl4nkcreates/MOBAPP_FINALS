const String GEMINI_API_KEY = "AIzaSyCIhtwH2NIVxF7roKd_A6nUQ1tuBm-HyTg";
